import socket
import threading
import tkinter as tk
import random

HOST = '127.0.0.1'
PORT = 55555

client = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
client.connect((HOST, PORT))

code = f"User{random.randint(1000,9999)}"

def receive():
    while True:
        try:
            message = client.recv(1024).decode('utf-8')
            chat_box.insert(tk.END, message + '\n')
        except:
            print("Disconnected from server")
            break

def write():
    message = message_entry.get()
    client.send(message.encode('utf-8'))
    message_entry.delete(0, tk.END)

def get_users():
    client.send("GET_USERS".encode('utf-8'))

window = tk.Tk()
window.title("Messenger10")

chat_box = tk.Text(window, height=20, width=50)
chat_box.pack()

message_entry = tk.Entry(window, width=40)
message_entry.pack(side=tk.LEFT)

send_button = tk.Button(window, text="Send", command=write)
send_button.pack(side=tk.LEFT)

users_button = tk.Button(window, text="Active Users", command=get_users)
users_button.pack(side=tk.LEFT)

receive_thread = threading.Thread(target=receive)
receive_thread.start()

window.mainloop()
