import socket
import threading

HOST = '0.0.0.0'
PORT = 55555

server = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
server.bind((HOST, PORT))
server.listen()

clients = {}
codes = {}

def broadcast(message, _client=None):
    for client in clients:
        if client != _client:
            try:
                client.send(message.encode('utf-8'))
            except:
                remove_client(client)

def handle(client):
    code = codes[client]
    while True:
        try:
            message = client.recv(1024).decode('utf-8')
            if message == 'GET_USERS':
                active_users = ', '.join(codes[c] for c in clients if c != client)
                client.send(f"Active users: {active_users}".encode('utf-8'))
            else:
                broadcast(f"{code}: {message}", client)
        except:
            remove_client(client)
            break

def remove_client(client):
    if client in clients:
        print(f"{codes[client]} disconnected.")
        broadcast(f"{codes[client]} has left the chat.")
        clients.pop(client)
        codes.pop(client)
        client.close()

def receive():
    print(f"Server started on {HOST}:{PORT}")
    while True:
        client, address = server.accept()
        code = f"User{str(address[1])[-4:]}"
        clients[client] = address
        codes[client] = code
        print(f"{code} connected from {str(address)}.")
        broadcast(f"{code} has joined the chat.")
        thread = threading.Thread(target=handle, args=(client,))
        thread.start()

receive()
